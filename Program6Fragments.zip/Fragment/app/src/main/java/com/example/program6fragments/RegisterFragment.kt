package com.example.program6fragments

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import java.util.Calendar
import androidx.navigation.fragment.findNavController

class RegisterFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_register, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etName = view.findViewById<TextInputEditText>(R.id.etName)
        val etDOB = view.findViewById<TextInputEditText>(R.id.etDOB)
        val etUsername = view.findViewById<TextInputEditText>(R.id.etUsername)
        val etPassword = view.findViewById<TextInputEditText>(R.id.etPassword)
        val rgGender = view.findViewById<RadioGroup>(R.id.rgGender)
        val etEmail = view.findViewById<TextInputEditText>(R.id.etEmail)
        val etPhone = view.findViewById<TextInputEditText>(R.id.etPhone)

        view.findViewById<Button>(R.id.btnGoBack).setOnClickListener(){
            requireActivity().supportFragmentManager.popBackStack()
        }
        etDOB?.setOnClickListener {
            showDatePickerDialog()
        }

        view.findViewById<Button>(R.id.btnRegister).setOnClickListener {
            val name = etName.text.toString()
            val dob = etDOB.text.toString()
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()
            val email = etEmail.text.toString()
            val phone = etPhone.text.toString()
            val gender = when (rgGender.checkedRadioButtonId) {
                R.id.rbMale -> "Male"
                R.id.rbFemale -> "Female"
                R.id.rbOther -> "Other"
                else -> "" // Handle default case or error
            }
            if (validateFields(name, dob, rgGender.checkedRadioButtonId)) {
                // Registration successful, navigate to login fragment
                Toast.makeText(requireContext(), "Registration Successful", Toast.LENGTH_LONG).show()
                val bundle = Bundle().apply {
                    putString("name", name)
                    putString("dob", dob)
                    putString("username", username)
                    putString("password", password)
                    putString("gender", gender)
                    putString("email", email)
                    putString("phone", phone)
                }
                // Navigate to the LoginFragment and pass the data bundle
                val loginFragment = LoginFragment()
                loginFragment.arguments = bundle

                val transaction = requireActivity().supportFragmentManager.beginTransaction()
                transaction.replace(R.id.frameLayout1, loginFragment)
                transaction.addToBackStack(null)
                transaction.commit()

            }
        }
    }

    private fun validateFields(name: String, dob: String, genderId: Int): Boolean {
        val etName = view?.findViewById<TextInputEditText>(R.id.etName)
        val etDOB = view?.findViewById<TextInputEditText>(R.id.etDOB)
        val etUsername = view?.findViewById<TextInputEditText>(R.id.etUsername)
        val etPassword = view?.findViewById<TextInputEditText>(R.id.etPassword)
        val etEmail = view?.findViewById<TextInputEditText>(R.id.etEmail)
        val etPhone = view?.findViewById<TextInputEditText>(R.id.etPhone)

        if (name.isEmpty()) {
            etName?.error = "Name cannot be empty"
            return false
        }

        if (!name.matches(Regex("[a-zA-Z]+"))) {
            etName?.error = "Name can only contain characters"
            return false
        }

        if (dob.isEmpty()) {
            etDOB?.error = "Date of Birth cannot be empty"
            return false
        }

        if (etEmail?.text.toString().isEmpty()) {
            etEmail?.error = "Email cannot be empty"
            return false
        }

        if (etPhone?.text.toString().isEmpty()) {
            etPhone?.error = "Phone cannot be empty"
            return false
        }

        if (genderId == -1) {
            Toast.makeText(requireContext(), "Please select a gender", Toast.LENGTH_SHORT).show()
            return false
        }

        if (etUsername?.text.toString().isEmpty()) {
            etUsername?.error = "Username cannot be empty"
            return false
        }

        if (etPassword?.text.toString().isEmpty()) {
            etPassword?.error = "Password cannot be empty"
            return false
        }
        return true
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            requireContext(),
            { _, selectedYear, selectedMonth, selectedDay ->
                val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                view?.findViewById<TextInputEditText>(R.id.etDOB)?.setText(selectedDate)
                view?.findViewById<TextInputEditText>(R.id.etDOB)?.error = null
            },
            year,
            month,
            day
        )

        datePickerDialog.show()
    }
}
