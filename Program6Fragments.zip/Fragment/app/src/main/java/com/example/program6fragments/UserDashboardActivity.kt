package com.example.program6fragments


import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class UserDashboardActivity : AppCompatActivity() {

    var name:String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_dashboard)

        // Retrieve data from the intent
        name = intent.getStringExtra("name")
        val dob = intent.getStringExtra("dob")
        val gender = intent.getStringExtra("gender")
        val email = intent.getStringExtra("email")
        val phone = intent.getStringExtra("phone")

        // Set click listener for the burger icon
        val burgerIcon = findViewById<ImageView>(R.id.burger_icon)
        burgerIcon.setOnClickListener {
            showPopupMenu(it)
        }

        // Load the default fragment
        loadFragment(UserHomeFragment())

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigationView.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.navigation_home -> {
                    // Handle navigation to home fragment
                    val bundle = Bundle().apply {
                        // Add data to the bundle
                        putString("name", name)
                    }
                    val userHomeFragment = UserHomeFragment().apply {
                        arguments = bundle
                    }
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frameLayout2, userHomeFragment)
                        .commit()
                    true
                }
                R.id.navigation_dashboard -> {
                    // Handle navigation to profile fragment
                    val bundle = Bundle().apply {
                        // Add data to the bundle
                        putString("name", name)
                        putString("dob", dob)
                        putString("gender", gender)
                        putString("email",email)
                        putString("phone",phone)
                    }

                    // Navigate to UserProfileFragment with the bundle
                    val userProfileFragment = UserProfileFragment().apply {
                        arguments = bundle
                    }
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frameLayout2, userProfileFragment)
                        .commit()
                    true
                }
                R.id.navigation_notifications -> {
                    // Handle navigation to notifications fragment
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frameLayout2, NotificationFragment())
                        .commit()
                    true
                }
                else -> false
            }
        }

    }

    // Function to show the popup menu
    private fun showPopupMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.menu_logout, popupMenu.menu)
        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_logout -> {
                    Toast.makeText(this, "Logged out!", Toast.LENGTH_LONG).show()
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                    true
                }
                R.id.action_Insights -> {
                    Toast.makeText(this, "!", Toast.LENGTH_LONG).show()
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.hindustantimes.com/cricket/ipl/team-stats"))
                    startActivity(browserIntent)
                    true
                }

                else -> false
            }
        }
        popupMenu.show()
    }

    // Function to load fragments
    private fun loadFragment(fragment: Fragment) {

        val bundle = Bundle().apply {
            // Add data to the bundle
            putString("name", name)
        }
        val userHomeFragment = fragment.apply {
            arguments = bundle
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.frameLayout2, userHomeFragment)
            .commit()
    }
}