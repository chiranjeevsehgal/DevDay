package com.example.program6fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class UserHomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_user_homepage, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Retrieve data from arguments bundle
        val args = arguments
        if (args != null) {
            val name = args.getString("name")

            // Display the retrieved user data in TextViews
            view.findViewById<TextView>(R.id.profile_name).text = "Hi $name!\uD83D\uDC4B\uD83C\uDFFB"
            var webViewLiveScore = view.findViewById<WebView>(R.id.webViewLiveScore)

            // Load the IPL website's live score URL in the WebView
            webViewLiveScore.loadUrl("https://www.iplt20.com/stats/2024")

// Set click listeners for social media buttons
            var btnTwitter = view.findViewById<Button>(R.id.btnTwitter)
            btnTwitter.setOnClickListener {
                val twitterIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/IPL"))
                startActivity(twitterIntent)
            }
            var btnFacebook = view.findViewById<Button>(R.id.btnFacebook)

            btnFacebook.setOnClickListener {
                val facebookIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/IPL"))
                startActivity(facebookIntent)
            }
            var btnInstagram = view.findViewById<Button>(R.id.btnInstagram)

            btnInstagram.setOnClickListener {
                val instagramIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/iplt20/"))
                startActivity(instagramIntent)
            }
        }
    }
}