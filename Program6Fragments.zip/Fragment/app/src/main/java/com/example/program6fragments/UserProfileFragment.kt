package com.example.program6fragments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class UserProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_user_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Retrieve data from arguments bundle
        val args = arguments
        if (args != null) {
            val name = args.getString("name")
            val dob = args.getString("dob")
            val gender = args.getString("gender")
            val email = args.getString("email")
            val phone = args.getString("phone")

            // Display the retrieved user data in TextViews
            view.findViewById<TextView>(R.id.tvName).text = name
            view.findViewById<TextView>(R.id.tvDOB).text = dob
            view.findViewById<TextView>(R.id.tvGender).text = gender
            view.findViewById<TextView>(R.id.tvEmail).text = email
            view.findViewById<TextView>(R.id.tvPhone).text = phone


            // Share Profile Button Click Listener
            view.findViewById<Button>(R.id.ShareProfile).setOnClickListener {
                // Create a string containing the user data
                val userData = "Name: $name\nDate of Birth: $dob\nGender: $gender\nEmail: $email\nPhone: $phone"

                // Copy user data to clipboard
                val clipboardManager =
                    requireActivity().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clipData = ClipData.newPlainText("User Data", userData)
                clipboardManager.setPrimaryClip(clipData)

                // Create an Intent to share the user data
                val shareIntent = Intent(Intent.ACTION_SEND)
                shareIntent.type = "text/plain"
                shareIntent.putExtra(Intent.EXTRA_TEXT, userData)
                startActivity(Intent.createChooser(shareIntent, "Share via"))
            }
        }
    }
}