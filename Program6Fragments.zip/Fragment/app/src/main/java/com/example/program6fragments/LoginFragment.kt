package com.example.program6fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.textfield.TextInputEditText

class LoginFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etUsername = view.findViewById<TextInputEditText>(R.id.etUsername)
        val etPassword = view.findViewById<TextInputEditText>(R.id.etPassword)

        // Retrieve data from arguments bundle
        val args = arguments
        var username: String? = null
        var password: String? = null
        var name: String? = null
        var dob: String? = null
        var gender: String? = null
        var email: String? = null
        var phone: String? = null
        if (args != null) {
            name = args.getString("name")
            dob = args.getString("dob")
            username = args.getString("username")
            password = args.getString("password")
            gender = args.getString("gender")
            email = args.getString("email")
            phone = args.getString("phone")
        }

        view.findViewById<Button>(R.id.btnLogin).setOnClickListener() {
            val inputUsername = etUsername.text.toString()
            val inputPassword = etPassword.text.toString()

            if (validateFields(inputUsername, inputPassword)) {
                if (inputUsername == username && inputPassword == password) {
                    // Valid username and password, navigate to user dashboard
                    Toast.makeText(requireContext(), "Login Successful!", Toast.LENGTH_SHORT).show()
                    val intentDashboard = Intent(requireContext(), UserDashboardActivity::class.java)
                    // Pass the data as extras to the UserDashboardActivity
                    intentDashboard.putExtra("name", name)
                    intentDashboard.putExtra("dob", dob)
                    intentDashboard.putExtra("gender", gender)
                    intentDashboard.putExtra("email", email)
                    intentDashboard.putExtra("phone", phone)
                    startActivity(intentDashboard)
                } else {
                    // Invalid username or password, show toast message
                    Toast.makeText(requireContext(), "Invalid username or password", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun validateFields(username: String, password: String): Boolean {
        val etUsername = view?.findViewById<TextInputEditText>(R.id.etUsername)
        val etPassword = view?.findViewById<TextInputEditText>(R.id.etPassword)

        if (username.isEmpty()) {
            etUsername?.error = "Username cannot be empty"
            return false
        }

        if (password.isEmpty()) {
            etPassword?.error = "Password cannot be empty"
            return false
        }

        return true
    }
}
